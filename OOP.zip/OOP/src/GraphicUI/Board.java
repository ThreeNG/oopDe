package GraphicUI;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.layout.FillLayout;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Canvas;
import Model.SquareRx;

import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;

public class Board extends Composite implements IBoard {
	SquareRx[][] squares;
    final int MARGIN_CELLS = 1; // margin range for the boundary of board game
    private int row = 20;
    private int col = 20;
    private Canvas canvas;
    private int turn = 1; // 1: player 1; 2: player 2
    private boolean hasWiner = false; // true or false
    private CaroGameView parentView;
	static int cell_sizeX = 1;
    static int cell_sizeY = 1;
    private boolean condition = false;
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
    public void setRow(int row)
    {
    	this.row = row;
    }
    
    public void setCol(int col)
    {
    	this.col = col;
    }
    public void setCondition(boolean condition)
    {
    	this.condition = condition;
    }
    
	public Board(Composite parent, int style) {
		super(parent, style);
		setLayout(new FillLayout(SWT.HORIZONTAL));

		parentView = CaroGameView.getIntance();
		canvas = new Canvas(this, SWT.NONE);
		canvas.setSize(parent.getSize());
		initBoardGame();
		
		canvas.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				int y = (int)(e.x / cell_sizeX) - 1;
				int x = (int)(e.y / cell_sizeY) - 1;
				if (!squares[x][y].isOccupied())
				{
					squares[x][y].setOccupied(true);
					squares[x][y].setTurn(turn);
					if (hasWiner())
						parentView.setWiner(turn);
					else
					{
						if (turn == 1)
							turn = 2; // turn of PLAYER 2
						else 
							turn = 1; // turn of PLAYER 1
						
						// update the new turn
						parentView.setTurnPlayer(turn);
					}
					
				}
			}
			@Override
			public void mouseUp(MouseEvent e) {
				System.out.println("123");
				canvas.redraw();
			}
		});
		canvas.addPaintListener(new PaintListener() {
			public void paintControl(PaintEvent e) {
				GC gc = e.gc;
				gc.setLineWidth(2);
		        int w = ((Canvas)e.widget).getSize().x;
		        int h = ((Canvas)e.widget).getSize().y;
		        cell_sizeX = (int)(w / (col + MARGIN_CELLS*2));
		        cell_sizeY = (int)(h / (row + MARGIN_CELLS*2));
		        // Draw vertical grid lines.
		        gc.setForeground(new org.eclipse.swt.graphics.Color(e.display, new RGB(0, 0, 0)));
		        int x0 = MARGIN_CELLS*cell_sizeX;
		        int y0 = MARGIN_CELLS*cell_sizeY;
		        for (int i = 0; i <= col; i++) {
		            int x = x0 + i*cell_sizeX;
		            gc.drawLine(x , y0, x, y0 + row*cell_sizeY);
		        }
		        // Draw horizontal grid lines.
		        for (int i = 0; i <= row; i++) {
		            int y = y0 + i*cell_sizeY;
		            gc.drawLine(x0 , y, x0 + col*cell_sizeX, y);
		        }
		        // Draw icon of players
		        for(int i = 0; i < row; i++) {
		            for(int j = 0; j < col; j++) {
		                if (squares[i][j].isOccupied())
		                {  				
		                	drawIcons(gc, squares[i][j].getTurn(), (i + MARGIN_CELLS) * cell_sizeY, (j + MARGIN_CELLS) * cell_sizeX);
		                }
		            }
		        }
		        gc.dispose();
				//canvas.redraw();
			}
		});
	}
	
	private void drawIcons(GC gc, int turn, int y, int x)
	{
		if (turn == 1)
		{
	        gc.setForeground(new org.eclipse.swt.graphics.Color(canvas.getDisplay(), new RGB(0, 255, 0)));
			gc.drawOval(x + cell_sizeX/10, y + cell_sizeY/10, cell_sizeX * 8/10, cell_sizeY* 8/10);
		}
		else
		{	
	        gc.setForeground(new org.eclipse.swt.graphics.Color(canvas.getDisplay(), new RGB(0, 0, 255)));
			gc.drawLine(x + cell_sizeX/10, y + cell_sizeY/10, x + cell_sizeX*9/10, y + cell_sizeY*9/10);
			gc.drawLine(x + cell_sizeX/10, y + cell_sizeY*9/10, x + cell_sizeX*9/10, y + cell_sizeY/10);
		}
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
	
	@Override
	public void initBoardGame()
	{
		int ROWS = row;
        int COLS = col;
        squares = new SquareRx[ROWS][COLS];
        for(int i = 0; i < ROWS; i++) {
            for(int j = 0; j < COLS; j++) {
                squares[i][j] = new SquareRx(i, j);
            }
        }
       canvas.redraw();
        canvas.addPaintListener(new PaintListener() {
			public void paintControl(PaintEvent e) {
				GC gc = e.gc;
				gc.setLineWidth(2);
		        int w = ((Canvas)e.widget).getSize().x;
		        int h = ((Canvas)e.widget).getSize().y;
		        cell_sizeX = (int)(w / (col + MARGIN_CELLS*2));
		        cell_sizeY = (int)(h / (row + MARGIN_CELLS*2));
		        // Draw vertical grid lines.
		        gc.setForeground(new org.eclipse.swt.graphics.Color(e.display, new RGB(0, 0, 0)));
		        int x0 = MARGIN_CELLS*cell_sizeX;
		        int y0 = MARGIN_CELLS*cell_sizeY;
		        for (int i = 0; i <= col; i++) {
		            int x = x0 + i*cell_sizeX;
		            gc.drawLine(x , y0, x, y0 + row*cell_sizeY);
		        }
		        // Draw horizontal grid lines.
		        for (int i = 0; i <= row; i++) {
		            int y = y0 + i*cell_sizeY;
		            gc.drawLine(x0 , y, x0 + col*cell_sizeX, y);
		        }
		        // Draw icon of players
		        for(int i = 0; i < row; i++) {
		            for(int j = 0; j < col; j++) {
		                if (squares[i][j].isOccupied())
		                {  				
		                	drawIcons(gc, squares[i][j].getTurn(), (i + MARGIN_CELLS) * cell_sizeY, (j + MARGIN_CELLS) * cell_sizeX);
		                }
		            }
		        }
		        gc.dispose();
				//canvas.redraw();
			}
		});
	}

	@Override
	public boolean hasWiner() {
		// call to check winer
		checkWiner();
		return hasWiner;
	}

	/**
	 * Check the winer after finishing player's turn
	 * @return 
	 */
	private void checkWiner() {
		hasWiner = false; //TODO: need to implement
		int count[] = {0,0};
		int p,q;
		
		boolean boundary;
		if (this.condition == true)
		{
			boundary = true;
		}
		else
			boundary = false;
		//System.out.print(boundary);
		for (int i = 0; i < row; i ++)
		{
			for (int j = 0; j < col; j++)
			{
				// ngang
				if (j + 5 <= col)
				{
					for (p = j; p < j + 5; p++)
					{
						if (squares[i][p].getTurn() != 0)
							count[squares[i][p].getTurn()-1] ++;
					}
					if (this.condition == true)
					{
						boundary = true;
						if (j -1 >= 0 && j +5 < col)
						{
							if (squares[i][j-1].getTurn() == 0 || squares[i][j+5].getTurn() == 0)
							{
								boundary = false;
							}
						}
						else 
							boundary = false;
					}
					if (count[0] == 5 && boundary == false)
					{
						hasWiner = true;
						turn = 1;
						return;
					}
					if (count[1] == 5 && boundary == false)
					{
						hasWiner = true;
						turn = 2;
						return;
					}
					count[0] = count[1] = 0;
				}
				// doc
				if ( i+ 5 <= col)
				{
					for (p = i; p < i + 5; p++)
					{
						if (squares[p][j].getTurn() != 0)
							count[squares[p][j].getTurn()-1] ++;
					}
					
					if (this.condition == true)
					{
						boundary = true;
						if (i -1 >= 0 && i +5 < row)
						{
							if (squares[i-1][j].getTurn() == 0 || squares[i+5][j].getTurn() == 0)
							{
								boundary = false;
							}
						}
						else 
							boundary = false;
					}
					if (count[0] == 5 && boundary == false)
					{
						hasWiner = true;
						turn = 1;
						return;
					}
					if (count[1] == 5 && boundary == false)
					{
						hasWiner = true;
						turn = 2;
						return;
					}
					count[0] = count[1] = 0;
				}
				// cheo
				if ( i + 5 <= row && j +5 <= col)
				{
					for (p = i, q = j; p < i + 5; p++, q++)
					{
						if (squares[p][q].getTurn() != 0)
							count[squares[p][q].getTurn()-1] ++;
					}
					
					if (this.condition == true)
					{
						boundary = true;
						if (j -1 >= 0 && i - 1 >= 0 && j +5 < col && i +5 < row)
						{
							if (squares[i-1][j-1].getTurn() == 0 || squares[i+5][j+5].getTurn() == 0)
							{
								boundary = false;
							}
						}
						else 
							boundary = false;
					}
					if (count[0] == 5 && boundary == false)
					{
						hasWiner = true;
						turn = 1;
						return;
					}
					if (count[1] == 5 && boundary == false)
					{
						hasWiner = true;
						turn = 2;
						return;
					}
					count[0] = count[1] = 0;
				}
				
				
				
				if ( i + 4 < row && j - 4 >= 0)
				{
					for (p = i+4, q = j-4; q <= j; p--, q++)
					{
						if (squares[p][q].getTurn() != 0)
							count[squares[p][q].getTurn()-1] ++;
					}
					
					if (this.condition == true)
					{
						boundary = true;
						if (j +1 < col && i - 1 >= 0 && j - 5 >= 0 && i + 5 < row)
						{
							if (squares[i-1][j+1].getTurn() == 0 || squares[i+5][j-5].getTurn() == 0)
							{
								boundary = false;
							}
						}
						else 
							boundary = false;
					}
					if (count[0] == 5 && boundary == false)
					{
						hasWiner = true;
						turn = 1;
						return;
					}
					if (count[1] == 5 && boundary == false)
					{
						hasWiner = true;
						turn = 2;
						return;
					}
					count[0] = count[1] = 0;
				}
			}
		}
		}

    @Override
    public int getTurn() {
		return turn;
	}
}
