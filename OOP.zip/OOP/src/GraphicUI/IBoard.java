package GraphicUI;

public interface IBoard {
	boolean hasWiner();
	void initBoardGame();
	int getTurn();
}
